﻿namespace GBMembership
{
    partial class MemberForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbLeader = new System.Windows.Forms.CheckBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.tbTitle = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbLast = new System.Windows.Forms.TextBox();
            this.tbAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.tbPostcode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbsigned = new System.Windows.Forms.TextBox();
            this.labela = new System.Windows.Forms.Label();
            this.dtpSigned = new System.Windows.Forms.DateTimePicker();
            this.gbMember = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tbpTitle = new System.Windows.Forms.TextBox();
            this.tbpName = new System.Windows.Forms.TextBox();
            this.tbpSurname = new System.Windows.Forms.TextBox();
            this.tbpAddress = new System.Windows.Forms.TextBox();
            this.tbpPostcode = new System.Windows.Forms.TextBox();
            this.tbpPhone = new System.Windows.Forms.TextBox();
            this.tbpMobile = new System.Windows.Forms.TextBox();
            this.tbpEmail = new System.Windows.Forms.TextBox();
            this.tbpSigned = new System.Windows.Forms.TextBox();
            this.dtppSigned = new System.Windows.Forms.DateTimePicker();
            this.cbpPermission = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbGP = new System.Windows.Forms.TextBox();
            this.tbMedical = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tbNotes = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cbMed = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpMedicalSign = new System.Windows.Forms.DateTimePicker();
            this.tbMedicalSign = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dtpaSigned = new System.Windows.Forms.DateTimePicker();
            this.label26 = new System.Windows.Forms.Label();
            this.tbaSigned = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbPhoto = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tb2Relation = new System.Windows.Forms.TextBox();
            this.dtp2Signed = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.tb2Signed = new System.Windows.Forms.TextBox();
            this.tb2Email = new System.Windows.Forms.TextBox();
            this.tb2Mobile = new System.Windows.Forms.TextBox();
            this.tb2Phone = new System.Windows.Forms.TextBox();
            this.tb2Postcode = new System.Windows.Forms.TextBox();
            this.tb2Address = new System.Windows.Forms.TextBox();
            this.tb2Surname = new System.Windows.Forms.TextBox();
            this.tb2Name = new System.Windows.Forms.TextBox();
            this.tb2Title = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tb1Relation = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.dtp1Signed = new System.Windows.Forms.DateTimePicker();
            this.tb1Signed = new System.Windows.Forms.TextBox();
            this.tb1Email = new System.Windows.Forms.TextBox();
            this.tb1Mobile = new System.Windows.Forms.TextBox();
            this.tb1Phone = new System.Windows.Forms.TextBox();
            this.tb1Postcode = new System.Windows.Forms.TextBox();
            this.tb1Address = new System.Windows.Forms.TextBox();
            this.tb1Surname = new System.Windows.Forms.TextBox();
            this.tb1Name = new System.Windows.Forms.TextBox();
            this.tb1Title = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.MemNo = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.gbMember.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbLeader
            // 
            this.cbLeader.AutoSize = true;
            this.cbLeader.Location = new System.Drawing.Point(12, 12);
            this.cbLeader.Name = "cbLeader";
            this.cbLeader.Size = new System.Drawing.Size(65, 17);
            this.cbLeader.TabIndex = 2;
            this.cbLeader.Text = "Leader?";
            this.cbLeader.UseVisualStyleBackColor = true;
            this.cbLeader.CheckedChanged += new System.EventHandler(this.DataChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(83, 13);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(27, 13);
            this.Label1.TabIndex = 3;
            this.Label1.Text = "Title";
            // 
            // tbTitle
            // 
            this.tbTitle.Location = new System.Drawing.Point(115, 10);
            this.tbTitle.Name = "tbTitle";
            this.tbTitle.Size = new System.Drawing.Size(68, 20);
            this.tbTitle.TabIndex = 4;
            this.tbTitle.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Name";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(231, 10);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(92, 20);
            this.tbName.TabIndex = 6;
            this.tbName.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(329, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Surname";
            // 
            // tbLast
            // 
            this.tbLast.Location = new System.Drawing.Point(384, 9);
            this.tbLast.Name = "tbLast";
            this.tbLast.Size = new System.Drawing.Size(100, 20);
            this.tbLast.TabIndex = 8;
            this.tbLast.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbAddress
            // 
            this.tbAddress.Location = new System.Drawing.Point(64, 32);
            this.tbAddress.Multiline = true;
            this.tbAddress.Name = "tbAddress";
            this.tbAddress.Size = new System.Drawing.Size(396, 67);
            this.tbAddress.TabIndex = 10;
            this.tbAddress.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(472, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Date of Birth";
            // 
            // dtpDOB
            // 
            this.dtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDOB.Location = new System.Drawing.Point(544, 32);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(96, 20);
            this.dtpDOB.TabIndex = 12;
            this.dtpDOB.ValueChanged += new System.EventHandler(this.DataChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(472, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Postcode";
            // 
            // tbPostcode
            // 
            this.tbPostcode.Location = new System.Drawing.Point(544, 58);
            this.tbPostcode.Name = "tbPostcode";
            this.tbPostcode.Size = new System.Drawing.Size(126, 20);
            this.tbPostcode.TabIndex = 14;
            this.tbPostcode.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(247, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Signed by";
            // 
            // tbsigned
            // 
            this.tbsigned.Location = new System.Drawing.Point(307, 110);
            this.tbsigned.Name = "tbsigned";
            this.tbsigned.Size = new System.Drawing.Size(126, 20);
            this.tbsigned.TabIndex = 16;
            this.tbsigned.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // labela
            // 
            this.labela.AutoSize = true;
            this.labela.Location = new System.Drawing.Point(505, 116);
            this.labela.Name = "labela";
            this.labela.Size = new System.Drawing.Size(21, 13);
            this.labela.TabIndex = 17;
            this.labela.Text = "On";
            // 
            // dtpSigned
            // 
            this.dtpSigned.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSigned.Location = new System.Drawing.Point(544, 110);
            this.dtpSigned.Name = "dtpSigned";
            this.dtpSigned.Size = new System.Drawing.Size(96, 20);
            this.dtpSigned.TabIndex = 18;
            this.dtpSigned.ValueChanged += new System.EventHandler(this.DataChanged);
            // 
            // gbMember
            // 
            this.gbMember.Controls.Add(this.label11);
            this.gbMember.Controls.Add(this.dtpSigned);
            this.gbMember.Controls.Add(this.labela);
            this.gbMember.Controls.Add(this.tbsigned);
            this.gbMember.Controls.Add(this.label7);
            this.gbMember.Controls.Add(this.tbPostcode);
            this.gbMember.Controls.Add(this.label6);
            this.gbMember.Controls.Add(this.dtpDOB);
            this.gbMember.Controls.Add(this.label5);
            this.gbMember.Controls.Add(this.tbAddress);
            this.gbMember.Location = new System.Drawing.Point(6, 6);
            this.gbMember.Name = "gbMember";
            this.gbMember.Size = new System.Drawing.Size(744, 146);
            this.gbMember.TabIndex = 19;
            this.gbMember.TabStop = false;
            this.gbMember.Text = "Personal Details of Member";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Title";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(111, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(250, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Surname";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 58);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Address";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(473, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Postcode";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(473, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Signed by";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(506, 120);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "On";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 143);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "Telephone";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(243, 143);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "Mobile";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(420, 143);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "email";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(571, 140);
            this.label19.MaximumSize = new System.Drawing.Size(140, 50);
            this.label19.MinimumSize = new System.Drawing.Size(140, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(140, 39);
            this.label19.TabIndex = 30;
            this.label19.Text = "Permission to store phone number on personal/group phone";
            // 
            // tbpTitle
            // 
            this.tbpTitle.Location = new System.Drawing.Point(33, 21);
            this.tbpTitle.Name = "tbpTitle";
            this.tbpTitle.Size = new System.Drawing.Size(68, 20);
            this.tbpTitle.TabIndex = 31;
            this.tbpTitle.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpName
            // 
            this.tbpName.Location = new System.Drawing.Point(144, 21);
            this.tbpName.Name = "tbpName";
            this.tbpName.Size = new System.Drawing.Size(100, 20);
            this.tbpName.TabIndex = 32;
            this.tbpName.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpSurname
            // 
            this.tbpSurname.Location = new System.Drawing.Point(302, 21);
            this.tbpSurname.Name = "tbpSurname";
            this.tbpSurname.Size = new System.Drawing.Size(100, 20);
            this.tbpSurname.TabIndex = 33;
            this.tbpSurname.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpAddress
            // 
            this.tbpAddress.Location = new System.Drawing.Point(55, 55);
            this.tbpAddress.Multiline = true;
            this.tbpAddress.Name = "tbpAddress";
            this.tbpAddress.Size = new System.Drawing.Size(366, 67);
            this.tbpAddress.TabIndex = 34;
            this.tbpAddress.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpPostcode
            // 
            this.tbpPostcode.Location = new System.Drawing.Point(545, 55);
            this.tbpPostcode.Name = "tbpPostcode";
            this.tbpPostcode.Size = new System.Drawing.Size(100, 20);
            this.tbpPostcode.TabIndex = 35;
            this.tbpPostcode.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpPhone
            // 
            this.tbpPhone.Location = new System.Drawing.Point(73, 140);
            this.tbpPhone.Name = "tbpPhone";
            this.tbpPhone.Size = new System.Drawing.Size(98, 20);
            this.tbpPhone.TabIndex = 36;
            this.tbpPhone.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpMobile
            // 
            this.tbpMobile.Location = new System.Drawing.Point(287, 140);
            this.tbpMobile.Name = "tbpMobile";
            this.tbpMobile.Size = new System.Drawing.Size(98, 20);
            this.tbpMobile.TabIndex = 37;
            this.tbpMobile.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpEmail
            // 
            this.tbpEmail.Location = new System.Drawing.Point(457, 140);
            this.tbpEmail.Name = "tbpEmail";
            this.tbpEmail.Size = new System.Drawing.Size(100, 20);
            this.tbpEmail.TabIndex = 38;
            this.tbpEmail.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbpSigned
            // 
            this.tbpSigned.Location = new System.Drawing.Point(545, 84);
            this.tbpSigned.Name = "tbpSigned";
            this.tbpSigned.Size = new System.Drawing.Size(100, 20);
            this.tbpSigned.TabIndex = 39;
            this.tbpSigned.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // dtppSigned
            // 
            this.dtppSigned.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtppSigned.Location = new System.Drawing.Point(545, 114);
            this.dtppSigned.Name = "dtppSigned";
            this.dtppSigned.Size = new System.Drawing.Size(126, 20);
            this.dtppSigned.TabIndex = 40;
            this.dtppSigned.ValueChanged += new System.EventHandler(this.DataChanged);
            // 
            // cbpPermission
            // 
            this.cbpPermission.AutoSize = true;
            this.cbpPermission.Location = new System.Drawing.Point(718, 150);
            this.cbpPermission.Name = "cbpPermission";
            this.cbpPermission.Size = new System.Drawing.Size(15, 14);
            this.cbpPermission.TabIndex = 41;
            this.cbpPermission.UseVisualStyleBackColor = true;
            this.cbpPermission.CheckedChanged += new System.EventHandler(this.DataChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbpPermission);
            this.groupBox1.Controls.Add(this.dtppSigned);
            this.groupBox1.Controls.Add(this.tbpSigned);
            this.groupBox1.Controls.Add(this.tbpEmail);
            this.groupBox1.Controls.Add(this.tbpMobile);
            this.groupBox1.Controls.Add(this.tbpPhone);
            this.groupBox1.Controls.Add(this.tbpPostcode);
            this.groupBox1.Controls.Add(this.tbpAddress);
            this.groupBox1.Controls.Add(this.tbpSurname);
            this.groupBox1.Controls.Add(this.tbpName);
            this.groupBox1.Controls.Add(this.tbpTitle);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(744, 194);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Details of Parent/Guardian";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 11);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(202, 13);
            this.label20.TabIndex = 43;
            this.label20.Text = "Name, Address and Phone number of GP";
            // 
            // tbGP
            // 
            this.tbGP.Location = new System.Drawing.Point(13, 29);
            this.tbGP.Multiline = true;
            this.tbGP.Name = "tbGP";
            this.tbGP.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbGP.Size = new System.Drawing.Size(636, 60);
            this.tbGP.TabIndex = 44;
            this.tbGP.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbMedical
            // 
            this.tbMedical.Location = new System.Drawing.Point(13, 121);
            this.tbMedical.Multiline = true;
            this.tbMedical.Name = "tbMedical";
            this.tbMedical.Size = new System.Drawing.Size(636, 60);
            this.tbMedical.TabIndex = 45;
            this.tbMedical.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 101);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(708, 13);
            this.label21.TabIndex = 46;
            this.label21.Text = "Details of any Medical conditions, allergies or special diets that leaders should" +
    " be aware of(including any medication that may be needed whilst at GB)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(10, 195);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(417, 13);
            this.label22.TabIndex = 47;
            this.label22.Text = "Details of any particular/additional needs your child has of which we should be a" +
    "wae of";
            // 
            // tbNotes
            // 
            this.tbNotes.Location = new System.Drawing.Point(13, 211);
            this.tbNotes.Multiline = true;
            this.tbNotes.Name = "tbNotes";
            this.tbNotes.Size = new System.Drawing.Size(636, 60);
            this.tbNotes.TabIndex = 48;
            this.tbNotes.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(19, 288);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(323, 13);
            this.label23.TabIndex = 49;
            this.label23.Text = "Agreement for GB collecting, storing and using sensitive information";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(377, 288);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 13);
            this.label24.TabIndex = 50;
            this.label24.Text = "Signed by";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(575, 288);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 13);
            this.label25.TabIndex = 51;
            this.label25.Text = "on";
            // 
            // cbMed
            // 
            this.cbMed.AutoSize = true;
            this.cbMed.Location = new System.Drawing.Point(345, 287);
            this.cbMed.Name = "cbMed";
            this.cbMed.Size = new System.Drawing.Size(15, 14);
            this.cbMed.TabIndex = 52;
            this.cbMed.UseVisualStyleBackColor = true;
            this.cbMed.CheckStateChanged += new System.EventHandler(this.DataChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpMedicalSign);
            this.groupBox2.Controls.Add(this.tbMedicalSign);
            this.groupBox2.Controls.Add(this.cbMed);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.tbNotes);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.tbMedical);
            this.groupBox2.Controls.Add(this.tbGP);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Location = new System.Drawing.Point(6, 158);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(748, 320);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Medical Details of Member";
            // 
            // dtpMedicalSign
            // 
            this.dtpMedicalSign.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpMedicalSign.Location = new System.Drawing.Point(600, 285);
            this.dtpMedicalSign.Name = "dtpMedicalSign";
            this.dtpMedicalSign.Size = new System.Drawing.Size(88, 20);
            this.dtpMedicalSign.TabIndex = 54;
            this.dtpMedicalSign.ValueChanged += new System.EventHandler(this.DataChanged);
            // 
            // tbMedicalSign
            // 
            this.tbMedicalSign.Location = new System.Drawing.Point(432, 285);
            this.tbMedicalSign.Name = "tbMedicalSign";
            this.tbMedicalSign.Size = new System.Drawing.Size(100, 20);
            this.tbMedicalSign.TabIndex = 53;
            this.tbMedicalSign.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 36);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(775, 634);
            this.tabControl1.TabIndex = 54;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.gbMember);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(767, 608);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "MemberDetails";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dtpaSigned);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.tbaSigned);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.cbPhoto);
            this.groupBox3.Location = new System.Drawing.Point(6, 484);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(691, 74);
            this.groupBox3.TabIndex = 57;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Authorisation";
            // 
            // dtpaSigned
            // 
            this.dtpaSigned.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpaSigned.Location = new System.Drawing.Point(452, 30);
            this.dtpaSigned.Name = "dtpaSigned";
            this.dtpaSigned.Size = new System.Drawing.Size(82, 20);
            this.dtpaSigned.TabIndex = 58;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(427, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 13);
            this.label26.TabIndex = 57;
            this.label26.Text = "on";
            // 
            // tbaSigned
            // 
            this.tbaSigned.Location = new System.Drawing.Point(305, 30);
            this.tbaSigned.Name = "tbaSigned";
            this.tbaSigned.Size = new System.Drawing.Size(100, 20);
            this.tbaSigned.TabIndex = 56;
            this.tbaSigned.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(232, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 55;
            this.label4.Text = "Signed By";
            // 
            // cbPhoto
            // 
            this.cbPhoto.AutoSize = true;
            this.cbPhoto.Location = new System.Drawing.Point(29, 32);
            this.cbPhoto.Name = "cbPhoto";
            this.cbPhoto.Size = new System.Drawing.Size(197, 17);
            this.cbPhoto.TabIndex = 54;
            this.cbPhoto.Text = "Permission to use images of Member";
            this.cbPhoto.UseVisualStyleBackColor = true;
            this.cbPhoto.CheckStateChanged += new System.EventHandler(this.DataChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.label38);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(767, 608);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Parent/Guardian Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tb2Relation);
            this.groupBox5.Controls.Add(this.dtp2Signed);
            this.groupBox5.Controls.Add(this.label49);
            this.groupBox5.Controls.Add(this.tb2Signed);
            this.groupBox5.Controls.Add(this.tb2Email);
            this.groupBox5.Controls.Add(this.tb2Mobile);
            this.groupBox5.Controls.Add(this.tb2Phone);
            this.groupBox5.Controls.Add(this.tb2Postcode);
            this.groupBox5.Controls.Add(this.tb2Address);
            this.groupBox5.Controls.Add(this.tb2Surname);
            this.groupBox5.Controls.Add(this.tb2Name);
            this.groupBox5.Controls.Add(this.tb2Title);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Location = new System.Drawing.Point(6, 428);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(744, 174);
            this.groupBox5.TabIndex = 44;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Emergency Contact 2";
            // 
            // tb2Relation
            // 
            this.tb2Relation.Location = new System.Drawing.Point(543, 21);
            this.tb2Relation.Name = "tb2Relation";
            this.tb2Relation.Size = new System.Drawing.Size(100, 20);
            this.tb2Relation.TabIndex = 44;
            this.tb2Relation.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // dtp2Signed
            // 
            this.dtp2Signed.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp2Signed.Location = new System.Drawing.Point(545, 114);
            this.dtp2Signed.Name = "dtp2Signed";
            this.dtp2Signed.Size = new System.Drawing.Size(126, 20);
            this.dtp2Signed.TabIndex = 40;
            this.dtp2Signed.ValueChanged += new System.EventHandler(this.DataChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(460, 24);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(65, 13);
            this.label49.TabIndex = 43;
            this.label49.Text = "Relationship";
            // 
            // tb2Signed
            // 
            this.tb2Signed.Location = new System.Drawing.Point(545, 84);
            this.tb2Signed.Name = "tb2Signed";
            this.tb2Signed.Size = new System.Drawing.Size(100, 20);
            this.tb2Signed.TabIndex = 39;
            this.tb2Signed.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Email
            // 
            this.tb2Email.Location = new System.Drawing.Point(457, 140);
            this.tb2Email.Name = "tb2Email";
            this.tb2Email.Size = new System.Drawing.Size(100, 20);
            this.tb2Email.TabIndex = 38;
            this.tb2Email.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Mobile
            // 
            this.tb2Mobile.Location = new System.Drawing.Point(287, 140);
            this.tb2Mobile.Name = "tb2Mobile";
            this.tb2Mobile.Size = new System.Drawing.Size(98, 20);
            this.tb2Mobile.TabIndex = 37;
            this.tb2Mobile.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Phone
            // 
            this.tb2Phone.Location = new System.Drawing.Point(73, 140);
            this.tb2Phone.Name = "tb2Phone";
            this.tb2Phone.Size = new System.Drawing.Size(98, 20);
            this.tb2Phone.TabIndex = 36;
            this.tb2Phone.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Postcode
            // 
            this.tb2Postcode.Location = new System.Drawing.Point(545, 55);
            this.tb2Postcode.Name = "tb2Postcode";
            this.tb2Postcode.Size = new System.Drawing.Size(100, 20);
            this.tb2Postcode.TabIndex = 35;
            this.tb2Postcode.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Address
            // 
            this.tb2Address.Location = new System.Drawing.Point(55, 55);
            this.tb2Address.Multiline = true;
            this.tb2Address.Name = "tb2Address";
            this.tb2Address.Size = new System.Drawing.Size(366, 67);
            this.tb2Address.TabIndex = 34;
            this.tb2Address.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Surname
            // 
            this.tb2Surname.Location = new System.Drawing.Point(302, 21);
            this.tb2Surname.Name = "tb2Surname";
            this.tb2Surname.Size = new System.Drawing.Size(100, 20);
            this.tb2Surname.TabIndex = 33;
            this.tb2Surname.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Name
            // 
            this.tb2Name.Location = new System.Drawing.Point(144, 21);
            this.tb2Name.Name = "tb2Name";
            this.tb2Name.Size = new System.Drawing.Size(100, 20);
            this.tb2Name.TabIndex = 32;
            this.tb2Name.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb2Title
            // 
            this.tb2Title.Location = new System.Drawing.Point(33, 21);
            this.tb2Title.Name = "tb2Title";
            this.tb2Title.Size = new System.Drawing.Size(68, 20);
            this.tb2Title.TabIndex = 31;
            this.tb2Title.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(420, 143);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 13);
            this.label27.TabIndex = 29;
            this.label27.Text = "email";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(243, 143);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(38, 13);
            this.label39.TabIndex = 28;
            this.label39.Text = "Mobile";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(9, 143);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(58, 13);
            this.label40.TabIndex = 27;
            this.label40.Text = "Telephone";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(506, 120);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(21, 13);
            this.label41.TabIndex = 26;
            this.label41.Text = "On";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(473, 87);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(54, 13);
            this.label42.TabIndex = 25;
            this.label42.Text = "Signed by";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(473, 58);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 13);
            this.label43.TabIndex = 24;
            this.label43.Text = "Postcode";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 58);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(45, 13);
            this.label44.TabIndex = 23;
            this.label44.Text = "Address";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(250, 24);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(49, 13);
            this.label45.TabIndex = 22;
            this.label45.Text = "Surname";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(111, 24);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 13);
            this.label46.TabIndex = 21;
            this.label46.Text = "Name";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(4, 24);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(27, 13);
            this.label47.TabIndex = 20;
            this.label47.Text = "Title";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 208);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(140, 13);
            this.label38.TabIndex = 44;
            this.label38.Text = "Emergency Contacts Details";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tb1Relation);
            this.groupBox4.Controls.Add(this.label48);
            this.groupBox4.Controls.Add(this.dtp1Signed);
            this.groupBox4.Controls.Add(this.tb1Signed);
            this.groupBox4.Controls.Add(this.tb1Email);
            this.groupBox4.Controls.Add(this.tb1Mobile);
            this.groupBox4.Controls.Add(this.tb1Phone);
            this.groupBox4.Controls.Add(this.tb1Postcode);
            this.groupBox4.Controls.Add(this.tb1Address);
            this.groupBox4.Controls.Add(this.tb1Surname);
            this.groupBox4.Controls.Add(this.tb1Name);
            this.groupBox4.Controls.Add(this.tb1Title);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Location = new System.Drawing.Point(6, 228);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(744, 194);
            this.groupBox4.TabIndex = 43;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Emergency Contact 1";
            // 
            // tb1Relation
            // 
            this.tb1Relation.Location = new System.Drawing.Point(545, 21);
            this.tb1Relation.Name = "tb1Relation";
            this.tb1Relation.Size = new System.Drawing.Size(100, 20);
            this.tb1Relation.TabIndex = 42;
            this.tb1Relation.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(462, 24);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(65, 13);
            this.label48.TabIndex = 41;
            this.label48.Text = "Relationship";
            // 
            // dtp1Signed
            // 
            this.dtp1Signed.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp1Signed.Location = new System.Drawing.Point(545, 114);
            this.dtp1Signed.Name = "dtp1Signed";
            this.dtp1Signed.Size = new System.Drawing.Size(126, 20);
            this.dtp1Signed.TabIndex = 40;
            this.dtp1Signed.ValueChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Signed
            // 
            this.tb1Signed.Location = new System.Drawing.Point(545, 84);
            this.tb1Signed.Name = "tb1Signed";
            this.tb1Signed.Size = new System.Drawing.Size(100, 20);
            this.tb1Signed.TabIndex = 39;
            this.tb1Signed.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Email
            // 
            this.tb1Email.Location = new System.Drawing.Point(457, 140);
            this.tb1Email.Name = "tb1Email";
            this.tb1Email.Size = new System.Drawing.Size(100, 20);
            this.tb1Email.TabIndex = 38;
            this.tb1Email.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Mobile
            // 
            this.tb1Mobile.Location = new System.Drawing.Point(287, 140);
            this.tb1Mobile.Name = "tb1Mobile";
            this.tb1Mobile.Size = new System.Drawing.Size(98, 20);
            this.tb1Mobile.TabIndex = 37;
            this.tb1Mobile.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Phone
            // 
            this.tb1Phone.Location = new System.Drawing.Point(73, 140);
            this.tb1Phone.Name = "tb1Phone";
            this.tb1Phone.Size = new System.Drawing.Size(98, 20);
            this.tb1Phone.TabIndex = 36;
            this.tb1Phone.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Postcode
            // 
            this.tb1Postcode.Location = new System.Drawing.Point(545, 55);
            this.tb1Postcode.Name = "tb1Postcode";
            this.tb1Postcode.Size = new System.Drawing.Size(100, 20);
            this.tb1Postcode.TabIndex = 35;
            this.tb1Postcode.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Address
            // 
            this.tb1Address.Location = new System.Drawing.Point(55, 55);
            this.tb1Address.Multiline = true;
            this.tb1Address.Name = "tb1Address";
            this.tb1Address.Size = new System.Drawing.Size(366, 67);
            this.tb1Address.TabIndex = 34;
            this.tb1Address.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Surname
            // 
            this.tb1Surname.Location = new System.Drawing.Point(302, 21);
            this.tb1Surname.Name = "tb1Surname";
            this.tb1Surname.Size = new System.Drawing.Size(100, 20);
            this.tb1Surname.TabIndex = 33;
            this.tb1Surname.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Name
            // 
            this.tb1Name.Location = new System.Drawing.Point(144, 21);
            this.tb1Name.Name = "tb1Name";
            this.tb1Name.Size = new System.Drawing.Size(100, 20);
            this.tb1Name.TabIndex = 32;
            this.tb1Name.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // tb1Title
            // 
            this.tb1Title.Location = new System.Drawing.Point(33, 21);
            this.tb1Title.Name = "tb1Title";
            this.tb1Title.Size = new System.Drawing.Size(68, 20);
            this.tb1Title.TabIndex = 31;
            this.tb1Title.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(420, 143);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(31, 13);
            this.label28.TabIndex = 29;
            this.label28.Text = "email";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(243, 143);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(38, 13);
            this.label29.TabIndex = 28;
            this.label29.Text = "Mobile";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 143);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(58, 13);
            this.label30.TabIndex = 27;
            this.label30.Text = "Telephone";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(506, 120);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(21, 13);
            this.label31.TabIndex = 26;
            this.label31.Text = "On";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(473, 87);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(54, 13);
            this.label32.TabIndex = 25;
            this.label32.Text = "Signed by";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(473, 58);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 13);
            this.label33.TabIndex = 24;
            this.label33.Text = "Postcode";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 58);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(45, 13);
            this.label34.TabIndex = 23;
            this.label34.Text = "Address";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(250, 24);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(49, 13);
            this.label35.TabIndex = 22;
            this.label35.Text = "Surname";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(111, 24);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(35, 13);
            this.label36.TabIndex = 21;
            this.label36.Text = "Name";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(4, 24);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(27, 13);
            this.label37.TabIndex = 20;
            this.label37.Text = "Title";
            // 
            // MemNo
            // 
            this.MemNo.AutoSize = true;
            this.MemNo.Location = new System.Drawing.Point(533, 16);
            this.MemNo.Name = "MemNo";
            this.MemNo.Size = new System.Drawing.Size(31, 13);
            this.MemNo.TabIndex = 55;
            this.MemNo.Text = "Mbr :";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(691, 6);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 56;
            this.btnClose.Text = "Close Screen";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCancel.Enabled = false;
            this.btnCancel.Location = new System.Drawing.Point(700, 672);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 57;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Visible = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(605, 672);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 58;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Visible = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(596, 6);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 59;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnDelete.Location = new System.Drawing.Point(520, 672);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 60;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // MemberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(800, 749);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.MemNo);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.cbLeader);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.tbTitle);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbLast);
            this.Name = "MemberForm";
            this.Text = "MemberForm";
            this.gbMember.ResumeLayout(false);
            this.gbMember.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox cbLeader;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.TextBox tbTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbLast;
        private System.Windows.Forms.TextBox tbAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbPostcode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbsigned;
        private System.Windows.Forms.Label labela;
        private System.Windows.Forms.DateTimePicker dtpSigned;
        private System.Windows.Forms.GroupBox gbMember;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbpTitle;
        private System.Windows.Forms.TextBox tbpName;
        private System.Windows.Forms.TextBox tbpSurname;
        private System.Windows.Forms.TextBox tbpAddress;
        private System.Windows.Forms.TextBox tbpPostcode;
        private System.Windows.Forms.TextBox tbpPhone;
        private System.Windows.Forms.TextBox tbpMobile;
        private System.Windows.Forms.TextBox tbpEmail;
        private System.Windows.Forms.TextBox tbpSigned;
        private System.Windows.Forms.DateTimePicker dtppSigned;
        private System.Windows.Forms.CheckBox cbpPermission;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbGP;
        private System.Windows.Forms.TextBox tbMedical;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbNotes;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox cbMed;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dtpMedicalSign;
        private System.Windows.Forms.TextBox tbMedicalSign;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DateTimePicker dtpaSigned;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbaSigned;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cbPhoto;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label MemNo;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox tb2Relation;
        private System.Windows.Forms.DateTimePicker dtp2Signed;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox tb2Signed;
        private System.Windows.Forms.TextBox tb2Email;
        private System.Windows.Forms.TextBox tb2Mobile;
        private System.Windows.Forms.TextBox tb2Phone;
        private System.Windows.Forms.TextBox tb2Postcode;
        private System.Windows.Forms.TextBox tb2Address;
        private System.Windows.Forms.TextBox tb2Surname;
        private System.Windows.Forms.TextBox tb2Name;
        private System.Windows.Forms.TextBox tb2Title;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tb1Relation;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.DateTimePicker dtp1Signed;
        private System.Windows.Forms.TextBox tb1Signed;
        private System.Windows.Forms.TextBox tb1Email;
        private System.Windows.Forms.TextBox tb1Mobile;
        private System.Windows.Forms.TextBox tb1Phone;
        private System.Windows.Forms.TextBox tb1Postcode;
        private System.Windows.Forms.TextBox tb1Address;
        private System.Windows.Forms.TextBox tb1Surname;
        private System.Windows.Forms.TextBox tb1Name;
        private System.Windows.Forms.TextBox tb1Title;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnDelete;
    }
}